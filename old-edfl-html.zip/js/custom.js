// JavaScript Document


$(function() {
	
	/* Top Search button */
	$('.fa-search').click(function(){
		$(this).addClass('yellow');
		$('.searchbox').fadeIn();
	});
	
});